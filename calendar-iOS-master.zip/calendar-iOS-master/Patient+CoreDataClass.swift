//
//  Patient+CoreDataClass.swift
//  Appt
//
//  Created by Agustin Mendoza Romo on 5/31/17.
//  Copyright © 2017 AgustinMendoza. All rights reserved.
//

import Foundation
import CoreData

@objc(Patient)
public class Patient: NSManagedObject {

}
