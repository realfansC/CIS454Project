//
//  CalendarDayCell.swift
//  Appt
//
//  Created by Agustin Mendoza Romo on 7/29/17.
//  Copyright © 2017 AgustinMendoza. All rights reserved.
//

import UIKit
import JTAppleCalendar

class CalendarDayCell: JTAppleCell {
  @IBOutlet weak var dateLabel: UILabel!
  @IBOutlet weak var selectedView: UIView!
  
}

