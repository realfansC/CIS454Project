//
//  PatientCell.swift
//  Appt
//
//  Created by Agustin Mendoza Romo on 5/22/17.
//  Copyright © 2017 AgustinMendoza. All rights reserved.
//

import UIKit

class PatientCell: UITableViewCell {

  @IBOutlet weak var patientNameLabel: UILabel!
  
}
