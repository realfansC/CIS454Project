//
//  ActivityCell.swift
//  Appt
//
//  Created by Agustin Mendoza Romo on 6/1/17.
//  Copyright © 2017 AgustinMendoza. All rights reserved.
//

import UIKit

class ActivityCell: UITableViewCell {

  @IBOutlet weak var timeIntervalLabel: UILabel!
  @IBOutlet weak var activityLabel: UILabel!
  
}
