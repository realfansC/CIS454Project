//
//  Constants.swift
//  cis454Demo
//
//  Created by 张尧大胖子 on 2/8/20.
//  Copyright © 2020 张尧. All rights reserved.
//

import Foundation

struct Constants {

    struct Storyboard {
        static let homeViewController = "HomeVC"
    }


}
